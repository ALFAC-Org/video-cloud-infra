const nodemailer = require('nodemailer');

exports.handler = async (event) => {
  console.log("Evento recebido")
  // Acessando os atributos da mensagem SNS
  const snsMessage = event.Records[0].Sns;
  const messageAttributes = snsMessage.MessageAttributes;

  console.log("SNS Message:", snsMessage);
  console.log("Message Attributes:", messageAttributes);

    // Criar o transportador
    let transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        auth: {
            user: 'alfacorg@gmail.com',
            pass: 'qryq yett yiuk lqhj'
        }
    });

    // Definir as opções do email
    let mailOptions = {
        from: 'remetente',
        to: messageAttributes.email.Value,
        subject: 'Erro no processamento do seu vídeo',
        text: 'Você está recebendo essa mensagem porque houve um erro no processamento do seu vídeo. Por favor, tente novamente mais tarde.'
    };

    // Enviar o email
    console.log('Enviando email...');
    try {
        let info = await transporter.sendMail(mailOptions);
        console.log('Email enviado: ' + info.response);
    } catch (error) {
        console.log(error);
    }
};
